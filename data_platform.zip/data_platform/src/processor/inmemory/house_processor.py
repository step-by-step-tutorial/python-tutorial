import hashlib
from collections.abc import Mapping

import pandas as pd
from pandas import DataFrame

import dataset.house.model as schema
from processor.base import DataProcessor
from transformation.inmemory.pandas_ops import (
    average_by_group,
    convert_boolean_column,
    convert_numeric_column,
    create_column,
    divide_columns,
    remove_duplicates,
    remove_rows_with_missing_values,
    rename_columns,
    reset_index,
    strip_string_column,
)

_RENAME = {
    schema.model.area_raw: schema.model.area,
    schema.model.room_raw: schema.model.room,
    schema.model.parking_raw: schema.model.parking,
    schema.model.warehouse_raw: schema.model.warehouse,
    schema.model.elevator_raw: schema.model.elevator,
    schema.model.address_raw: schema.model.address,
    schema.model.price_raw: schema.model.price,
    schema.model.price_usd_raw: schema.model.price_usd,
}


def create_listing_key(row: pd.Series) -> str:
    price_usd = (
        ""
        if pd.isna(row[schema.model.price_usd])
        else f"{float(row[schema.model.price_usd]):.6f}"
    )

    parts = (
        f"{float(row[schema.model.area]):.6f}",
        str(int(row[schema.model.room])),
        str(bool(row[schema.model.parking])).lower(),
        str(bool(row[schema.model.warehouse])).lower(),
        str(bool(row[schema.model.elevator])).lower(),
        "" if pd.isna(row[schema.model.address]) else str(row[schema.model.address]),
        f"{float(row[schema.model.price]):.6f}",
        price_usd,
    )

    return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()


class InmemoryHouseProcessor(DataProcessor[DataFrame]):

    def clean(self, dataframe: DataFrame) -> DataFrame:
        df = dataframe.copy()

        df = rename_columns(df, _RENAME)

        df = convert_numeric_column(df, schema.model.area)
        df = convert_numeric_column(df, schema.model.room)
        df = convert_numeric_column(df, schema.model.price)
        df = convert_numeric_column(df, schema.model.price_usd)

        df = convert_boolean_column(df, schema.model.parking)
        df = convert_boolean_column(df, schema.model.warehouse)
        df = convert_boolean_column(df, schema.model.elevator)

        df = strip_string_column(df, schema.model.address)

        df = remove_rows_with_missing_values(
            df,
            [
                schema.model.area,
                schema.model.room,
                schema.model.price,
            ],
        )

        df = reset_index(
            df=df,
            conditions=[
                df[schema.model.area] > 0,
                df[schema.model.room] >= 0,
                df[schema.model.price] > 0,
            ],
        )

        df = remove_duplicates(df)

        return df

    def enrich(self, dataframe: DataFrame) -> DataFrame:
        df = dataframe.copy()

        df = divide_columns(
            df=df,
            numerator_field=schema.model.price,
            denominator_field=schema.model.area,
            alias_field=schema.model.price_per_square_meter,
        )

        df = divide_columns(
            df=df,
            numerator_field=schema.model.price_usd,
            denominator_field=schema.model.area,
            alias_field=schema.model.price_usd_per_square_meter,
        )

        df = create_column(
            df=df,
            alias_field=schema.model.listing_key,
            function=create_listing_key,
        )

        return df

    def analyze(self, dataframe: DataFrame) -> Mapping[str, DataFrame]:
        return {
            "average_price_by_address": average_by_group(
                df=dataframe,
                group_field=schema.model.address,
                original_field=schema.model.price,
                alias_field="average_price",
            ),
            "average_price_by_square_meter": average_by_group(
                df=dataframe,
                group_field=schema.model.room,
                original_field=schema.model.price_per_square_meter,
                alias_field="average_price_by_square_meter",
            ),
        }
